
#Matrix Multiplication:
aa <- matrix(c(0.3909334,0.7665842,0.2036516,0.8309291,0.4181528,0.4182180,0.6547570,0.7140503,
    0.6572924,0.52187303,0.70818227,0.02469917),3,4)
m.data <- as.data.frame(aa, stringsAsFactors=F)
names(m.data) <- c("class1","class2","class3","class4")
a1 <- m.data==apply(m.data,1,max)
storage.mode(a1) <- "integer"
c1 <- apply(a1 %*% diag(1:4),1,sum)
#apply(abs(m.data==apply(m.data,1,max))%*% diag(1:4),1,sum)





#SVD:
aa <- matrix(0,12,9)
aa[1,1] = aa[2,1] = aa[3,1] = aa[3:7,2] = aa[9,2] = aa[2,3] = aa[4:5,3] = aa[8,3] = aa[1,4] = aa[8,4] = aa[4,5] = aa[6:7,5] = aa[10,6] = aa[10:11,7] = aa[10:12,8] = aa[9,9] = aa[11:12,9] = 1
aa[5,4] = 2
svd.data <- as.data.frame(aa, stringsAsFactors=F)
svd.data$Words <- c("����","�ӿ�","�����","�û�","ϵͳ","��Ӧ","ʱ��","EPS","����","��","ͼ","��ʽ")
svd.data <- svd.data[,c(10,1:9)]
names(svd.data) <- c("words","a1","a2","a3","a4","a5","b1","b2","b3","b4")
#svd.data
svd.res <- svd(svd.data[,2:10])





#Allpy:
mat1 <- matrix(rep(seq(4), 4), ncol = 4)
#row sums of mat1
apply(mat1, 1, sum)
#column sums of mat1
apply(mat1, 2, sum)
#creating a data frame using mat1
mat1.df <- data.frame(mat1)
#obtaining the sum of each variable in mat1.df
lapply(mat1.df, sum)
lapply(c("abc","df","we"),nchar)
lapply(1:5, function(i)i+1)
sapply(1:5, function(i)i+1,simplify=F)
sapply(1:5, function(i)i+1)

require(stats)
groups <- as.factor(rbinom(32, n = 5, prob = 0.4))
tapply(groups, groups, length)
table(groups)
tapply(warpbreaks$breaks, warpbreaks[,-1], sum)

a <- matrix(runif(100, 1, 2),20)
colMeans(a)
a1 <- sweep(a, 2, colMeans(a), "-")
a1[1:5,  ]
sweep(a,2,1:5,"+")





#Monte-Carlo:
con <- function(n = 50000, con = 14){
  x <- 0
  for(i in 1:n){
    nums <- sort(sample(1138,514))
    nums1 <- nums[1:(514-con + 1)]
    nums2 <- nums[con:514]
    flag <- nums2-nums1
    if(any(flag==(con-1))) x <- x + 1
  }
  x/n
}
con()





#Optimization Methods:
require(lpSolve)
f.obj <- c(1, 9, 3)
f.con <- matrix (c(1, 2, 3, 3, 2, 2), nrow=2, byrow=TRUE)
f.dir <- c("<=", "<=")
f.rhs <- c(9, 15)
lp("max", f.obj, f.con, f.dir, f.rhs)
lp("max", f.obj, f.con, f.dir, f.rhs)$solution





#Regular Expression:
sub("^a","",c("abcd","dcba"))
sub("a$","",c("abcd","dcba"))
sub("a.c","",c("abcd","sdacd"))
sub("a*b","",c("aabcd","dcaaaba"))
sub("a.*e","",c("abcde","edcba"))
sub("ab|ba","",c("abcd","dcba"))
sub("a.*b","",c("aabab","eabbe"))
sub("a.*?b","",c("aabab","eabbe"))





#Database:
require("RSQLite")
cdb <- dbConnect(dbDriver("SQLite"), "D:/chinaR3/chinaR3.db")
dbWriteTable(cdb, "svd", svd.data, append = TRUE)

res <- dbSendQuery(cdb, 'select * from svd')
aa <- fetch(res, n = -1)
dbClearResult(res)
