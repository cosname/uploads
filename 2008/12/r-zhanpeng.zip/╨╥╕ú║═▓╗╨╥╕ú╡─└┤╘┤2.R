#�Ҹ���Դ
data2a<-read.delim("E:/data/data2a.txt");
data2b<-read.delim("E:/data/data2b.txt");
#########-------------------------------�Ľ���ĳ���---------------------
#��1������Ӧλ�õĵ÷�ֵ
y<-data2a[1:7];yy<-data2a[8]
yy.tr<-matrix(rep(yy,7),nrow=length(yy))
yc<-y*yy.tr
NA->yc[yc==0]
result1.2a<-apply(yc,2,function(yc) c("����"=length(yc[!is.na(yc)]),
                                      "����(%)"=length(yc[!is.na(yc)])/337*100,
                                      "��ֵ"=mean(yc[!is.na(yc)]),
                                      "��׼��"=sd(yc[!is.na(yc)]) ))
y<-data2b[1:7];yy<-data2b[8]
yy.tr<-matrix(rep(yy,7),nrow=length(yy))
yc<-y*yy.tr
NA->yc[yc==0]
result1.2b<-apply(yc,2,function(yc) c("����"=length(yc[!is.na(yc)]),
                                      "����(%)"=length(yc[!is.na(yc)])/337*100,
                                      "��ֵ"=mean(yc[!is.na(yc)]),
                                      "��׼��"=sd(yc[!is.na(yc)]) ))
result1.2a
result1.2b
#########-----------------------------����Ʒ------------------
set.seed(1)
x = matrix(rbinom(700, 1, 0.3),100)

NA->x[x==0]

apply(x, 2, function(x) c(a = sum(x[!is.na(x)]), b = mean(x[!is.na(x)]), c = sd(x[!is.na(x)])))

##########-----------------------------ԭ����-----------------------
result1.2a<-array(0,dim=c(4,7));
result1.2b<-array(0,dim=c(4,7));
colnames(result1.2a)<-names(data2a[1:7]);
colnames(result1.2b)<-names(data2b[1:7]);
rownames(result1.2a)<-c("����","����(%)","��ֵ","��׼��")
rownames(result1.2b)<-c("����","����(%)","��ֵ","��׼��")

#result1.2a
for(i in 1:7){
  t<-data2a[i];x<-t[t[]==1];
    result1.2a[1,i]<-sum(x);
    result1.2a[2,i]<-sum(x)/337*100;
  x<-data2a[8];y<-x[t[]==1];
    result1.2a[3,i]<-mean(y);
    result1.2a[4,i]<-sd(y);
}
#result1.2b
for(i in 1:7){
  t<-data2b[i];x<-t[t[]==1];
    result1.2b[1,i]<-sum(x);
    result1.2b[2,i]<-sum(x)/337*100;
  x<-data2b[8];y<-x[t[]==1];
    result1.2b[3,i]<-mean(y);
    result1.2b[4,i]<-sd(y);
}
result1.2a
result1.2b