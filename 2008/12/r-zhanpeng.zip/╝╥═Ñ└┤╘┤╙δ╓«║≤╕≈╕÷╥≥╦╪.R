data1<-read.delim("E:/data/data1.txt");

home<-data1[5];
bro<-data1[6];
out<-data1[7];
pers<-data1[8];

result1.3d<-array(0,dim=c(6,9));
colnames(result1.3d)<-names(data1[rep(c(6,7,8),3)]);
for(j in 0:2){
for(i in 1:6){
  x<-bro[home==j+1];
   y<-x[x==i];
   result1.3d[i,3*j+1]<-length(y)/length(x);
  x<-out[home==j+1];
   y<-x[x==i];
   result1.3d[i,3*j+2]<-length(y)/length(x);
  x<-pers[home==j+1];
   y<-x[x==i];
   result1.3d[i,3*j+3]<-length(y)/length(x);
}
}
result1.3d