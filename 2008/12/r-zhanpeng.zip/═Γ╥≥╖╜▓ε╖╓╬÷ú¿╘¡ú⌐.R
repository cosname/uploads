data3<-read.table("E:/data/data3.txt",header=TRUE)

##############
anova.tab<-function(fm){
  tab<-summary(fm)
  k<-length(tab[[1]])-2
  temp<-c(sum(tab[[1]][,1]),sum(tab[[1]],[,2]),rep(NA,k))
  tab[[1]]["Total",]<-temp
  tab
}
##############

data3.1<-data3[c(1:6)]
index<-data3[14]
x<-data3.1[6]
index=t(index);as.numeric(index);index=t(index);
index.f<-data.frame(index,x=factor(t(x)));
inner.aov<-aov(index ~ x,data=index.f)
summary(inner.aov)
source("E:/ʵ��/R��̳/�ҵ�����/r/anova.tab.R");anova.tab(inner.aov)

########################################################################

data33<-read.table("E:/data/data33.txt",header=TRUE)

data33.1<-data33[c(1:7)]
index<-data33[15]
x<-data33.1[7]
index=t(index);as.numeric(index);index=t(index);
index.f<-data.frame(index,x=factor(t(x)));
inner.aov<-aov(index ~ x,data=index.f)
summary(inner.aov)
source("E:/ʵ��/R��̳/�ҵ�����/r/anova.tab.R");anova.tab(inner.aov)

##############################################################

data333<-read.table("E:/data/data333.txt",header=TRUE)

data333.1<-data333[c(1:8)]
index<-data333[9]
x<-data333.1[9]
index=t(index);as.numeric(index);index=t(index);
index.f<-data.frame(index,x=factor(t(x)));
inner.aov<-aov(index ~ x,data=index.f)
summary(inner.aov)
source("E:/ʵ��/R��̳/�ҵ�����/r/anova.tab.R");anova.tab(inner.aov)

