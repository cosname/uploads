data1<-read.delim("E:/data/data1.txt");

#1�������
index<-data1$�÷�;
result<-array(0,dim=c(2,3));
colnames(result)<-c("��ֵ","����","��׼��");
result[1]<-mean(index);result[3]<-var(index);result[5]<-sd(index);
result

x<-30:90;
hist(index,freq=F)
lines(density(index),col=2)
lines(x,dnorm(x,mean(index),sd(index)),col=3,lty=2)

shapiro.test(index)

#indexΪ�Ҹ�ָ����������
count1<-numeric()
for(i in 1:10){
  count1[i]<-length(index[index>(10*(i-1))&index<=10*(i)])/length(index)
}

#index.bΪ�Ҹ�ָ����������
data2a<-read.table("E:/data/data1b.txt")
index.b<-data2a[1]
count2<-numeric()
for(i in 1:10){
  count2[i]<-length(index.b[index.b==i])
  count2[i]<-count2[i]/length(t(index.b))
}

count<-matrix(0,nrow=2,ncol=10);
for(i in 1:10){
  count[1,i]<-count1[i];
  count[2,i]<-count2[i];
}


#------------------------------------------------#

