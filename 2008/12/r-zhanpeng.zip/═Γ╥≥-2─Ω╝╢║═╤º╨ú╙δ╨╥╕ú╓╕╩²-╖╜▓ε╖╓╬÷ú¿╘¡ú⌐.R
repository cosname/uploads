data1<-read.table("E:/data/data1.txt",header=TRUE)

##############
anova.tab<-function(fm){
  tab<-summary(fm)
  k<-length(tab[[1]])-2
  temp<-c(sum(tab[[1]][,1]),sum(tab[[1]],[,2]),rep(NA,k))
  tab[[1]]["Total",]<-temp
  tab
}
##############

index<-data1$�÷�
x<-data1$�꼶
index=t(index);index<-as.numeric(index);
index.f<-data.frame(index,x=factor(t(x)));
inner.aov<-aov(index ~ x,data=index.f)
source("E:/ʵ��/R��̳/�ҵ�����/r/anova.tab.R");
�꼶<-anova.tab(inner.aov);�꼶

index<-data1$�÷�
x<-data1$ѧУ
index=t(index);index<-as.numeric(index);
index.f<-data.frame(index,x=factor(t(x)));
inner.aov<-aov(index ~ x,data=index.f)
source("E:/ʵ��/R��̳/�ҵ�����/r/anova.tab.R");anova.tab(inner.aov)