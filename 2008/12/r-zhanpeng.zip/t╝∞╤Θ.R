data1<-read.delim("E:/data/data1.txt");

index<-data1[9];
x<-data1[2];
sex1<-index[x[]==1];sex2<-index[x[]==2];
t.test(sex1,sex2,var.equal=TRUE,alternative="less")

index<-data1[9];
x<-data1[4];
sch1<-index[x[]==1];sch2<-index[x[]==6];
t.test(sch1,sch2,var.equal=TRUE,alternative="less")
