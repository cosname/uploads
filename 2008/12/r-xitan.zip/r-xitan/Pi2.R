mc1<-function(n){
   set.seed(1234579)
   k<-0;
   x<-runif(n);
   y<-runif(n);
   k <- length(x[x^2+y^2 < 1])
   data.frame(Pi=4*k/n)
}